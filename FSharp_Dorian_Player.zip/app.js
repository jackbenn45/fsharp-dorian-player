
let tempo = 120;

function playChord(chord) {
    const synth = new Tone.PolySynth(Tone.Synth).toDestination();
    const now = Tone.now();
    const chords = {
        "F#m7": ["F#3", "A3", "C#4", "E4"],
        "Amaj7": ["A3", "C#4", "E4", "G#4"],
        "Bm7": ["B3", "D4", "F#4", "A4"],
        "C#7": ["C#3", "E#3", "G#3", "B4"]
    };
    synth.triggerAttackRelease(chords[chord], "2n", now);
}

function updateTempo(value) {
    tempo = value;
    document.getElementById("tempoValue").innerText = `${tempo} BPM`;
    Tone.Transport.bpm.value = tempo;
}
